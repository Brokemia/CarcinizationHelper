local trigger = {}

trigger.name = "BrokemiaHelper/carcinizationTrigger"
trigger.placements = {
    name = "trigger",
    data = {
        endLevel = true,
        type = "random"
    }
}

return trigger